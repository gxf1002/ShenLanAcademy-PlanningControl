# CARLA Walker Agent

An simple walker agent that can follow a given route.

## Publications

| Topic                              | Type                | Description                 |
| ---------------------------------- | ------------------- | --------------------------- |
| `/carla/<ROLE NAME>/walker_control_cmd` | [carla_msgs.CarlaWalkerControl](https://github.com/carla-simulator/ros-carla-msgs/tree/master/msg/CarlaWalkerControl.msg) | Walker control command |
