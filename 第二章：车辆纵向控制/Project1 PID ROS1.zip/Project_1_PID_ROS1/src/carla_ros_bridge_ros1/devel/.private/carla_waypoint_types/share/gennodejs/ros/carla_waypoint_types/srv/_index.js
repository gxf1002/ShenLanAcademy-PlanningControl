
"use strict";

let GetWaypoint = require('./GetWaypoint.js')
let GetActorWaypoint = require('./GetActorWaypoint.js')

module.exports = {
  GetWaypoint: GetWaypoint,
  GetActorWaypoint: GetActorWaypoint,
};
