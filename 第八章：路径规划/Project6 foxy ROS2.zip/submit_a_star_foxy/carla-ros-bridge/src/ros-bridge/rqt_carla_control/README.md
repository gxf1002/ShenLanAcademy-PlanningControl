# CARLA Control RQT Plugin

Find documentation about the CARLA Control RQT Plugin [__here__](https://carla.readthedocs.io/projects/ros-bridge/en/latest/rqt_plugin/).